<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\CKEditor;

class CKEditorController extends Controller
{
    public function index(Request $request){
        $ckeditor_detail = CKEditor::get()->toArray();
        return view('admin.ckeditor.index',compact('ckeditor_detail'));     
    }

    public function getCkeditor(Request $request){
    	if($request->isMethod('post')){
    		$request->validate([
    			'test_ckeditor' => 'required'
    		]);

    		$save_ckeditor = new CKEditor;
    		$save_ckeditor->content = $request->test_ckeditor;
    		$save_ckeditor->save();

    		return redirect()->route('ckeditor.index');
    	}
    	return view('admin.ck_editor');
    }

    public function editCKEditor($id){
        $ckeditor_detail = CKEditor::find($id);
        return view('admin.ckeditor.edit',compact('ckeditor_detail'));
    }

    public function updateCKEditor(Request $request){
        $request->validate([
            'test_ckeditor' => 'required'
        ]);
        $update_ckeditor = CKEditor::find($request['id']);
        $update_ckeditor->content = $request['test_ckeditor'];
        $update_ckeditor->save();
        return redirect()->route('ckeditor.index');
    }
}
