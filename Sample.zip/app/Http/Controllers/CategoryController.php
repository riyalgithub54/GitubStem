<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Category;

class CategoryController extends Controller
{
    public function addCategory(Request $request){

    	if($request->isMethod('post')){
    		$request->validate([
    			'name' => 'required|string',
    			'description' => 'required|string',
    			'url' => 'required'
    		]);
    		$data = $request->all();

    		$save_category = new Category;
            $save_category->name = $data['name'];
    		$save_category->parent_id = $data['parent_id'];
    		$save_category->description = $data['description'];
    		$save_category->url = $data['url'];
    		$save_category->save();
    	}

        $levels = Category::where(['parent_id'=>0])->get();

    	return view('admin.categories.add_category',compact('levels'));
    }

    public function viewCategory(Request $request){
        $category_detail = Category::get()->toArray();
        return view('admin.categories.viewcategory',compact('category_detail'));
    }

    public function editCategory(Request $request, $id = null ){
        if($request->isMethod('post')){
            Category::where(['id'=>$id])->update(['name'=>$request['name'], 'description'=>$request->description, 'url'=>$request->url]);

            return redirect()->route('category.view');
        }

        $category_detail = Category::where(['id'=>$id])->first();
        $levels = Category::where(['parent_id'=>0])->get();

        return view('admin.categories.edit_category',compact('category_detail','levels'));
    }

    public function deleteCategory($id = null){
        if(!empty($id)){
            Category::where(['id'=>$id])->delete();

            return redirect()->back();
        }
    }
}
