<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DropZoneContrller extends Controller
{
    public function dropzone()
    {
        return view('dropzone-view');
    }
    
    public function dropzoneStore(Request $request)
    {
    	dd($request->all());
        $image = $request->file('file');
        $imageName = time().$image->getClientOriginalName();
        $image->move(public_path('images'),$imageName);
        return response()->json(['success'=>$imageName]);
    }
}
