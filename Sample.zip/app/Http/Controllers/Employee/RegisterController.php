<?php

namespace App\Http\Controllers\Employee;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\EmployeeRequest;
use App\Events\EmployeeEvent;
use Event,Hash;
use App\Employee;

class RegisterController extends Controller
{
    public function getRegister(){
    	return view('employee.register');
    }

    public function postRegister(EmployeeRequest $request){
    	$emp_data = $request->all();
    	$emp_detail = [
    		'emp_data' => $emp_data
    	];

    	$imageName = time().'.'.request()->profile_picture->getClientOriginalExtension();
        request()->profile_picture->move(public_path('emp_images'), $imageName);

    	$save_emp = new Employee;
    	$save_emp->fill($emp_detail['emp_data']);
    	$save_emp->password = Hash::make($emp_detail['emp_data']['password']);
    	$save_emp->profile_picture = $imageName;
    	$save_emp->save();

    	// Event::fire(new EmployeeEvent($emp_detail));
    	return redirect()->back();
    }
}
