<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Auth;
use Session;
use Image;
use App\Category;
use App\Product;

class ProductsController extends Controller
{

    public function viewProducts(){
        $products = Product::get();
        foreach ($products as $key => $value) {
            $category_name = Category::where(['id'=>$value->category_id])->first();
            $products[$key]->category_name = $category_name->name;
        }
        return view('admin.products.view_products',compact('products'));   
    }

    public function addProduct(Request $request){
    	if($request->isMethod('post')){
    		$request->validate([
    			'category_id' => 'required',
    			'product_name' => 'required|string',
    			'product_code' => 'required|string',
    			'product_color' => 'required|string',
    			'price' => 'required|numeric'
    		]);

    		if(empty($request->category_id)){
    			return redirect()->back();
    		}
    		$save_product = new Product;
    		$save_product->category_id = $request->category_id;
    		$save_product->product_name = $request->product_name;
    		$save_product->product_code = $request->product_code;
    		$save_product->product_color = $request->product_color;
    		$save_product->description = $request->description;
    		$save_product->price = $request->price;
    	
        	// Upload Product Image with resize [ Intervention Package ]
            if($request->hasFile('image')){
                $image_tmp = Input::file('image');
                if($image_tmp->isValid()){
                    
                    $extension = $image_tmp->getClientOriginalExtension();
                    $filename = rand(111,99999) . '.' . $extension;

                    $large_image_path = 'backend/images/products/large/' . $filename;
                    $medium_image_path = 'backend/images/products/medium/' . $filename;
                    $small_image_path = 'backend/images/products/small/' . $filename;

                    // Resize Image
                    Image::make($image_tmp)->save($large_image_path);
                    Image::make($image_tmp)->resize(600,600)->save($medium_image_path);
                    Image::make($image_tmp)->resize(300,300)->save($small_image_path);

                    // Store image name in products table
                    $save_product->image = $filename;
                }
            }
        	
            $save_product->save();

            // return redirect()->back();
    		return redirect('/admin/view-products');
    	}

        // Category Dropdown start
        $categories = Category::where(['parent_id'=>0])->get();
        $categories_dropdown = "<option selected disabled>Select</option>";
        foreach($categories as $cat){
            $categories_dropdown .= "<option value='".$cat->id."'>" . $cat->name . "</option>";
            $sub_categories = Category::where(['parent_id'=>$cat->id])->get();
            foreach ($sub_categories as $sub_cat) {
                $categories_dropdown .= "<option value = '". $sub_cat->id ."'> &nbsp;--&nbsp;" . $sub_cat->name . "</option>";
            }
        }
        // Category Dropdown end

        return view('admin.products.add_product',compact('categories_dropdown'));
    }
    
    public function editProduct(Request $request, $id = null ){

        if($request->isMethod('post')){
            $data = $request->all();

            // Upload Product Image with resize [ Intervention Package ]
            if($request->hasFile('image')){
                $image_tmp = Input::file('image');
                if($image_tmp->isValid()){
                    
                    $extension = $image_tmp->getClientOriginalExtension();
                    $filename = rand(111,99999) . '.' . $extension;

                    $large_image_path = 'backend/images/products/large/' . $filename;
                    $medium_image_path = 'backend/images/products/medium/' . $filename;
                    $small_image_path = 'backend/images/products/small/' . $filename;

                    // Resize Image
                    Image::make($image_tmp)->save($large_image_path);
                    Image::make($image_tmp)->resize(600,600)->save($medium_image_path);
                    Image::make($image_tmp)->resize(300,300)->save($small_image_path);
                }
            }else{
                $filename = $data['current_image'];
            }

            Product::where(['id'=>$id])->update(
                ['category_id'=>$data['category_id'], 'product_name'=>$data['product_name'], 
                'product_code'=>$data['product_code'], 'product_color'=>$data['product_color'], 
                'description'=>$data['description'], 'price'=>$data['price'], 'image'=>$filename]);

            return redirect()->route('products.view');
        }

        // Get Product Detail
        $productDetail = Product::where(['id'=>$id])->first();
        
        // Category Dropdown start
        $categories = Category::where(['parent_id'=>0])->get();
        $categories_dropdown = "<option selected disabled>Select</option>";
        foreach($categories as $cat){
            if($cat->id == $productDetail->category_id){
                $selected = "selected";
            }else{
                $selected = "";
            }
            $categories_dropdown .= "<option value='".$cat->id."' ".$selected.">" . $cat->name . "</option>";
            $sub_categories = Category::where(['parent_id'=>$cat->id])->get();
            foreach ($sub_categories as $sub_cat) {
                if($sub_cat->id == $productDetail->category_id){
                    $selected = "selected";
                }else{
                    $selected = "";
                }
                $categories_dropdown .= "<option value = '". $sub_cat->id ."' ".$selected."> &nbsp;--&nbsp;" . $sub_cat->name . "</option>";
            }
        }
        // Category Dropdown end

        return view('admin.products.edit_products',compact('productDetail','categories_dropdown'));
    }

    public function deleteProductImage($id = null){
        Product::where(['id'=>$id])->update(['image'=>'']);

        return redirect()->back(); 
    }

    public function deleteProduct($id = null){
        Product::where(['id'=>$id])->delete();
        return redirect()->back();
    }

    public function addAttributes(Request $request, $id = null){
        return view('admin.products.add_attributes');
    }
}