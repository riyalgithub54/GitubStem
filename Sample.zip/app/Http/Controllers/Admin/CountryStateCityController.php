<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Country;
use App\State;
use App\City;
use App\EmpAddress;

class CountryStateCityController extends Controller
{
    public function getCountryStateCity(){
    	$country_list = Country::pluck('name','id');
    	// dd($country_list);
    	return view('admin.country_state_city',compact('country_list'));
    }

    public function store(Request $request){
        $errors = request()->validate([
            'name' => 'required',
            'address' => 'required',
            'country' => 'required',
            'state' => 'required',
            'city' => 'required'
        ]);
        // echo '<pre>';
        // print_r($request->all());
        // exit;
        $empDetails = [
            'name' => $request->name,
            'address' => $request->address,
            'country_id' => $request->country,
            'state_id' => $request->state,
            'city_id' => $request->city
        ];

        // dd($empDetails);
        $saveEmpAddress = new EmpAddress;
        $saveEmpAddress->fill($empDetails);
        $saveEmpAddress->updated_at = date('Y-m-d H:i:s');
        $saveEmpAddress->created_at = date('Y-m-d H:i:s');
        $saveEmpAddress->save();

        return response()->json(['success'=>'success','message'=>'done'],200);
    }

    public function getStates(Request $request){
        $country_id = $request->country_id;
        $state_list = State::where(['country_id'=>$country_id])->pluck('name','id');
        
        return response()->json(['success'=>'success','states'=>$state_list],200);
    }
    public function getCities(Request $request){
        $state_id = $request->state_id;
        $city_list = City::where(['state_id'=>$state_id])->pluck('name','id');
        
        return response()->json(['success'=>'success','cities'=>$city_list],200);
    }
}