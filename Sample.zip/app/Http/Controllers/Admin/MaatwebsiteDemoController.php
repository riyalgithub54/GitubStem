<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;
use Excel,Input;
use App\UserNew;

class MaatwebsiteDemoController extends Controller
{
    public function downloadExcel($type)
	{
		$data = UserNew::get()->toArray();
		return Excel::create('userdata_example', function($excel) use ($data) {
			$excel->sheet('userSheet', function($sheet) use ($data)
	        {
				$sheet->fromArray($data);
	        });
		})->download($type);
	}
	public function importExcel()
	{
		if(Input::hasFile('import_file')){
			$path = Input::file('import_file')->getRealPath();
			$data = Excel::load($path, function($reader) {
			})->get();
			if(!empty($data) && $data->count()){
				foreach ($data as $key => $value) {
					$insert[] = ['id' => $value->id,
								'name' => $value->name,
								'email' => $value->email,
								'gender' => $value->gender,
								'contact_no' => $value->contact_no,
								'department' => $value->department];
				}
				
				foreach ($insert as $single_user) {
					$exist_user = UserNew::find($single_user['id']);
					if(!empty($exist_user)){
						unset($single_user['id']);
						$exist_user->fill($single_user);
						$exist_user->save();
						// DB::table('usernew')->update($single_user);
					}else{
						DB::table('usernew')->insert($single_user);
					}
					
				}
			}
		}
		return back();
	}
}
