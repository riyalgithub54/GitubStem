<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Article;
use App\User;

class EloquentTipsController extends Controller
{
    public function getEloquentDetails(Request $request){
    	
    	/* ------------------- Start Increament & Decrement ------------------- */
    	// $articles = Article::get()->toArray();

    	/* Instead of us this method */
  		// $article = Article::find(1);
		// $article->read_count++;
		// $article->save();

    	/* You can do this: */
		// $article = Article::find(1);
		// $article->increment('read_count');

    	/* Also these will work: */
		Article::find(1)->increment('read_count');
    	/* ==================================================================== */
    	
    	// Example 1 – findOrFail():
    	/* ------------------ Start XorY methods -------------------- */
    	/* Instead of: */
  		// $user = User::find(2);
		// if (!$user) { abort (404); }

    	/* Do this: */
		$user = User::findOrFail(1);
    	
    	// Example 2 – firstOrCreate():
    	/* ------------------ Start XorY methods -------------------- */
    	$email = "riyalp@gmail.com";
    	$name = "Test";
    	$password = "Test123";
    	$user = User::where(['name'=>$name,'password'=>$password,'email'=> $email])->first();
		if (!$user) {
		  User::create([
		    'email' => $email,
		    'name'=>$name
		  ]);
		}
    }
}
