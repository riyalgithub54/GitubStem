<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\UserNew;

class ServerSideDataTableController extends Controller
{
    public function index(Request $request){
	   $newuser_detail = UserNew::get()->toArray();
       
       return view('admin.serverside.index',compact('newuser_detail'));
   	}
}
