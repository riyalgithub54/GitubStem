<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    protected $table = "products";
    
    protected $fillable = ['id','category_id','product_name','product_code','product_color','description','price','image'];
}
