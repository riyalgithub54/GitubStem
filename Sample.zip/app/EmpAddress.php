<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmpAddress extends Model
{
    protected $table = "emp_address";
    protected $fillable = ['id','name','address','country_id','state_id','city_id'];
}
