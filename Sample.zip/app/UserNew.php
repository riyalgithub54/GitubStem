<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserNew extends Model
{
    protected $table = "usernew";

    protected $fillable = ['id','name','email','contact_no','department'];  
}
