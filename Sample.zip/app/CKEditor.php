<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CKEditor extends Model
{
    protected $table = "ckeditor";

    protected $fillable = ['id','content'];
}
