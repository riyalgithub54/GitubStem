@extends('admin.adminlayout.layout')
@section('content')
    <div class="main-page">
        <div class="panel panel-default">
            <div class="panel-heading" align="left">User Details | <a href="{{URL::route('user.create')}}">Create User</a></div>
            <div class="panel-body">
                <table class="table table-striped">
                    <thead>
                      <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Contact No</th>
                        <th>Gender</th>
                        <th>Department</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      @foreach($newuser_detail as $single_user)
                        <tr>
                          <td>{{$single_user['name']}}</td>
                          <td>{{$single_user['email']}}</td>
                          <td>{{$single_user['contact_no']}}</td>
                          <td>{{$single_user['gender']}}</td>
                          <td>{{$single_user['department']}}</td>
                          <td>
                              <a href="{{URL::route('user.edit',$single_user['id'])}}">Edit</a> | 
                              <a href="{{URL::route('user.delete',$single_user['id'])}}">Delete</a></td>
                        </tr>
                      @endforeach
                    </tbody>
                </table>
                {{ $newuser_detail->links() }}<br>
                <hr>
                <b>Additional Information :-</b><br> 
                <hr>
                <b>count:  </b>{{ $newuser_detail->count() }}<br>
                <b>currentPage : </b>{{ $newuser_detail->currentPage() }}<br>
                <b>firstItem : </b>{{ $newuser_detail->firstItem() }}<br>
                <b>hasMorePages :  </b>{{ $newuser_detail->hasMorePages() }}<br>
                <b>lastItem :  </b>{{ $newuser_detail->lastItem() }}<br>
                <b>lastPage :  </b>{{ $newuser_detail->lastPage() }}<br>
                <b>nextPageUrl : </b>{{ $newuser_detail->nextPageUrl() }}<br>
                <b>perPage : </b>{{ $newuser_detail->perPage() }}<br>
                <b>previousPageUrl : </b>{{ $newuser_detail->previousPageUrl() }}<br>
                <b>total : </b>{{ $newuser_detail->total() }}<br>
            </div>
        </div>
    </div>
@endsection
@section('javascript')
  <script type="text/javascript">
    $(document).ready(function() {
      // show when page load
      // toastr.success('Page Loaded!');
        
        @if(Session::has('message'))
          var type = "{{ Session::get('alert-type', 'info') }}";
          switch(type){
              
              case 'info':
                  toastr.info("{{ Session::get('message') }}");
                  break;
              
              case 'warning':
                  toastr.warning("{{ Session::get('message') }}");
                  break;

              case 'success':
                  toastr.success("{{ Session::get('message') }}");
                  break;

              case 'error':
                  toastr.error("{{ Session::get('message') }}");
                  break;
          }
        @endif
    });
  </script>
@endsection