
@extends('admin.adminlayout.layout')
@section('style')
    <style type="text/css">
    	select {
		    width: 100%;
		    height: 100%;
		}
    </style>
@endsection
@section('content')
	<div class="row">
		<h3 class="title1">User Update</h3>
		<div class="form-three widget-shadow">
            
            <form method="POST" action="{{ route('user.update') }}">
                @csrf
                <input type="hidden" name="id" value="{{ $edit_newuser['id'] }}">
                <div class="form-group row">
                    <label for="name" class="col-md-4 col-form-label text-md-right">{{ __('Name') }}</label>

                    <div class="col-md-6">
                        <input id="name" type="text" class="form-control" name="name" value="{{ $edit_newuser['name'] }}">

                        @if ($errors->has('name'))
                            <span class="invalid-feedback">
                                <strong>{{ $errors->first('name') }}</strong>
                            </span>
                        @endif
                    </div>
                </div>

            	<div class="form-group row">
                    <label for="email" class="col-md-4 col-form-label text-md-right">{{ __('E-Mail Address') }}</label>

                    <div class="col-md-6">
                        <input id="email" type="email" class="form-control" name="email" value="{{ $edit_newuser['email'] }}">

                        @if ($errors->has('email'))
                            <span class="invalid-feedback">
                                <strong>{{ $errors->first('email') }}</strong>
                            </span>
                        @endif
                    </div>
                </div>

            	<div class="form-group row">
                    <label for="contact_no" class="col-md-4 col-form-label text-md-right">{{ __('Contact No') }}</label>

                    <div class="col-md-6">
                        <input id="contact_no" type="contact_no" class="form-control" name="contact_no" value="{{ $edit_newuser['contact_no'] }}">

                        @if ($errors->has('contact_no'))
                            <span class="invalid-feedback">
                                <strong>{{ $errors->first('contact_no') }}</strong>
                            </span>
                        @endif
                    </div>
                </div>

            	<div class="form-group row">
                    <label for="Gender" class="col-md-4 col-form-label text-md-right">{{ __('Gender') }}</label>

                    <div class="col-md-6">
                        <input type="radio" name="gender" value="male" @if($edit_newuser['gender'] == "male") checked="checked" @endif>Male
                        <input type="radio" name="gender" value="female"  @if($edit_newuser['gender'] == "female") checked="checked" @endif>Female
                    </div>
                </div>

            	<div class="form-group row">
                    <label for="Department" class="col-md-4 col-form-label text-md-right">{{ __('Department') }}</label>

                    <div class="col-md-6">
                    	<select name="department"  class="form-control1">
                    		<option value="" style="display: none;">Select any department</option>
                    		<option value="development" @if($edit_newuser['department'] == "development") selected="selected" @endif>Development</option>
                    		<option value="architech" @if($edit_newuser['department'] == "architech") selected="selected" @endif>Architech</option>
                    		<option value="accountant" @if($edit_newuser['department'] == "accountant") selected="selected" @endif>Accountant</option>
                    	</select>
                    </div>
                </div>
                <div class="form-group row mb-0">
                    <div class="col-md-6 offset-md-4">
                        <button type="submit" class="btn btn-primary">
                            Update User
                        </button>
                    </div>
                </div>
            </form>
		</div>
	</div>
@endsection