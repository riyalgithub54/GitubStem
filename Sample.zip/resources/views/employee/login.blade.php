<!DOCTYPE HTML>
<html>
<head>
<title>Employee Panel</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<!-- Bootstrap Core CSS -->
<link href="<?= url('/') ?>/backend/css/bootstrap.css" rel='stylesheet' type='text/css' />

<!-- Custom CSS -->
<link href="<?= url('/') ?>/backend/css/style.css" rel='stylesheet' type='text/css' />
<!-- font-awesome icons CSS-->
<link href="<?= url('/') ?>/backend/css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons CSS-->
 
 <!-- js-->
<script src="<?= url('/') ?>/backend/js/jquery-1.11.1.min.js"></script>
<script src="<?= url('/') ?>/backend/js/modernizr.custom.js"></script>

<!--webfonts-->
<link href="//fonts.googleapis.com/css?family=PT+Sans:400,400i,700,700i&amp;subset=cyrillic,cyrillic-ext,latin-ext" rel="stylesheet">
<!--//webfonts-->
 
<!-- Metis Menu -->
<script src="<?= url('/') ?>/backend/js/metisMenu.min.js"></script>
<script src="<?= url('/') ?>/backend/js/custom.js"></script>
<link href="<?= url('/') ?>/backend/css/custom.css" rel="stylesheet">
<!--//Metis Menu -->
<style type="text/css">
    .alert {
        padding: 2.5px;
    }
</style>
</head> 
<body>
<div class="main-content">
        <!-- main content start-->
        <div id="page-wrapper">
            <div class="main-page login-page ">
                <h2 class="title1">Employee Login</h2>
                <div class="widget-shadow">
                    <div class="login-body">
                        <form action="{{URL::route('emp.login.post')}}" method="post">
                            @csrf
                            <input type="email" class="user" name="email" placeholder="Enter Your Email">
                            @if ($errors->has('email'))
                                <span class="alert alert-danger">
                                    <strong>{{ $errors->first('email') }}</strong>
                                </span>
                            @endif
                            <input type="password" name="password" class="lock" placeholder="Password">
                            @if ($errors->has('password'))
                                <span class="alert alert-danger">
                                    <strong>{{ $errors->first('password') }}</strong>
                                </span>
                            @endif
                            <div class="forgot-grid">
                                <label class="checkbox"><input type="checkbox" name="checkbox" checked=""><i></i>Remember me</label>
                                <div class="forgot">
                                    <a href="#">forgot password?</a>
                                </div>
                                <div class="clearfix"> </div>
                            </div>
                            <input type="submit" name="Sign In" value="Sign In">
                            <div class="registration">
                                Don't have an account ?
                                <a class="" href="{{URL::route('emp.register.get')}}">
                                    Create an account
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--scrolling js-->
    <script src="<?= url('/') ?>/backend/js/jquery.nicescroll.js"></script>
    <script src="<?= url('/') ?>/backend/js/scripts.js"></script>
    <!--//scrolling js-->
    
    <!-- Bootstrap Core JavaScript -->
   <script src="<?= url('/') ?>/backend/js/bootstrap.js"> </script>
    <!-- //Bootstrap Core JavaScript -->
</body>
</html>