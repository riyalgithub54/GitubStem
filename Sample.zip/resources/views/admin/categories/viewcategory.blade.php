@extends('admin.adminlayout.layout')

@section('content')
    <div class="main-page">
		<div class="panel panel-default">
            <div class="panel-body">
           		<table id="example" class="display" style="width:100%">
			        <thead>
			            <tr>
			                <th>ID</th>
			                <th>Cateogry Name</th>
			                <th>Category Level</th>
			                <th>URL</th>
			                <th>Action</th>
			            </tr>
			        </thead>
			        <tbody>
			        	@foreach($category_detail as $single_category)
			        		<tr>
			        			<td>{{$single_category['id']}}</td>
			        			<td>{{$single_category['name']}}</td>
			        			<td>{{$single_category['parent_id']}}</td>
			        			<td>{{$single_category['url']}}</td>
			        			<td><a href="{{url('/admin/edit-category/' . $single_category['id'] )}}"><img border="0" alt="{{$single_category['name']}}" src="{{ url('/') .'/images/edit-button-blue-md.png' }}" width="50" height="25"></a> || <a id="deleteConfirmation" href="{{url('/admin/delete-category/' . $single_category['id'] )}}"><img border="0" alt="{{$single_category['name']}}" src="{{ url('/') .'/images/delete-png.png' }}" width="50" height="25"></a></td>
			        		</tr>
			        	@endforeach
			        </tbody>
			    </table> 	
            </div>
        </div>
    </div>
@endsection
@section('javascript')
	<script type="text/javascript">
		$(document).ready(function(){
			$('#example').DataTable();
		});

		$('#deleteConfirmation').click(function(){
			if(confirm('Are you sure you want to delete this Category')){
				return true;
			}
			return false;
		});
	</script>
@endsection