
@extends('admin.adminlayout.layout')
@section('style')
    <style type="text/css">
    	select {
		    width: 100%;
		    height: 100%;
		}
    </style>
@endsection
@section('content')
	<div class="row">
		<h3 class="title1">Add Category</h3>
		<div class="form-three widget-shadow">
            <form method="POST" action="{{ url('/admin/add-category') }}">
                @csrf

                <div class="form-group row">
                    <label for="name" class="col-md-4 col-form-label text-md-right">{{ __('Category Name') }}</label>

                    <div class="col-md-6">
                        <input id="name" type="text" class="form-control" name="name" value="{{ old('name') }}">

                        @if ($errors->has('name'))
                            <span class="alert alert-danger">
                                <strong>{{ $errors->first('name') }}</strong>
                            </span>
                        @endif
                    </div>
                </div>
                <div class="form-group row">
                    <label for="level" class="col-md-4 col-form-label text-md-right">{{ __('Category Level') }}</label>

                    <div class="col-md-6">
                        <select name="parent_id" class="form-control">
                            <option value="0">Main Category</option>
                            @foreach($levels as $single)
                            <option value="{{$single->id}}">{{$single->name}}</option>
                            @endforeach
                        </select>
                        @if ($errors->has('parent_id'))
                            <span class="alert alert-danger">
                                <strong>{{ $errors->first('parent_id') }}</strong>
                            </span>
                        @endif
                    </div>
                </div>

            	<div class="form-group row">
                    <label for="description" class="col-md-4 col-form-label text-md-right">{{ __('Description') }}</label>

                    <div class="col-md-6">
                        <input id="description" type="text" class="form-control" name="description" value="{{ old('description') }}">

                        @if ($errors->has('description'))
                            <span class="alert alert-danger">
                                <strong>{{ $errors->first('description') }}</strong>
                            </span>
                        @endif
                    </div>
                </div>

            	<div class="form-group row">
                    <label for="url" class="col-md-4 col-form-label text-md-right">{{ __('URL') }}</label>

                    <div class="col-md-6">
                        <input id="url" type="text" class="form-control" name="url" value="{{ old('url') }}">

                        @if ($errors->has('url'))
                            <span class="alert alert-danger">
                                <strong>{{ $errors->first('url') }}</strong>
                            </span>
                        @endif
                    </div>
                </div>

                <div class="form-group row mb-0" style="margin-top: 5%;">
                    <div class="col-md-6 offset-md-4">
                        <button type="submit" class="btn btn-primary">
                            Create Category
                        </button>
                    </div>
                </div>
            </form>
		</div>
	</div>
@endsection