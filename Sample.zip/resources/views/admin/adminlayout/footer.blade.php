<!--footer-->
	<div class="footer">
	   <p>&copy; 2018 Glance Design Dashboard. All Rights Reserved | Design by <a href="https://google.com/" target="_blank">FullStack Developer</a></p>		
	</div>
    <!--//footer-->