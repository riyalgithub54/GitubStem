@extends('admin.adminlayout.layout')

@section('content')
    <div class="main-page">
		<h2>Welcome in New Panel</h2>
    </div>
@endsection