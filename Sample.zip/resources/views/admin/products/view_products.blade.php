@extends('admin.adminlayout.layout')

@section('content')
    <div class="main-page">
		<div class="panel panel-default">
            <div class="panel-body">
           		<table id="example" class="display" style="width:100%">
			        <thead>
			            <tr>
			                <th>Product ID</th>
			                <th>Category ID</th>
			                <th>Category Name</th>
			                <th>Product Name</th>
			                <th>Product Code</th>
			                <th>Product Color</th>
			                <th>Price</th>
			                <th>Image</th>
			                <th>Action</th>
			            </tr>
			        </thead>
			        <tbody>
			        	@foreach($products as $product)
			        		<tr>
			        			<td>{{$product['id']}}</td>
			        			<td>{{$product['category_id']}}</td>
			        			<td>{{$product['category_name']}}</td>
			        			<td>{{$product['product_name']}}</td>
			        			<td>{{$product['product_code']}}</td>
			        			<td>{{$product['product_color']}}</td>
			        			<td>{{$product['price']}}</td>
			        			<td>
			        				@if(!empty($product['image']))
			        					<img src="{{asset('/backend/images/products/small/'.$product['image'])}}" style="width: 60px;">
			        				@endif
			        			</td>
			        			<td><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal{{$product['id']}}">View</button> | <a href="{{url('/admin/edit-product/' . $product['id'] )}}" class="btn btn-warning btn-mini">Edit</a> | <a id="deleteConfirmation"  onclick="test(<?php echo $product['id']; ?>)" href="#" class="btn btn-danger btn-mini">Delete</a></td>
			        		</tr>
						    <!-- Modal -->
						  	<div class="modal fade" id="myModal{{$product['id']}}" role="dialog">
							    <div class="modal-dialog">
							    	<!-- Modal content-->
								    <div class="modal-content">
								        <div class="modal-header">
								          <button type="button" class="close" data-dismiss="modal">&times;</button>
								          <h4 class="modal-title">{{$product['product_name']}} Full Details</h4>
								        </div>
								        <div class="modal-body">
								          <p>Product ID			: 	{{$product['id']}}</p>
								          <p>Category ID		: 	{{$product['category_id']}}</p>
								          <p>Product Code		: 	{{$product['product_code']}}</p>
								          <p>Product Color		: 	{{$product['product_color']}}</p>
								          <p>Price				: 	{{$product['price']}}</p>
								          <p>Description		: 	{{$product['description']}}</p>
								        </div>
								        <div class="modal-footer">
								          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
								        </div>
								    </div>
							    </div>
						  	</div>
			        	@endforeach
			        </tbody>
			    </table> 	
            </div>
        </div>
    </div>
@endsection
@section('javascript')
	<script type="text/javascript">
		$(document).ready(function(){
			$('#example').DataTable();
		});

		// $('#deleteConfirmation').click(function(){
		// 	if(confirm('Are you sure you want to delete this Product')){
		// 		return true;
		// 	}
		// 	return false;
		// });
		
		function test(test){
			var url = "{{url('/admin/delete-product/')}}" + "/"+test;
			$.confirm({
			    title: 'Alert!',
			    content: 'Simple alert!',
			    theme: 'modern',
			    buttons: {
			        confirm: function () {
			            window.location.href = url;
			        },
			        cancel: function () {
			            // $.alert('Canceled!');
			        }
			    }
			});
		}

		// $('#deleteConfirmation').click(function(){
			
		// });
	</script>
@endsection