
@extends('admin.adminlayout.layout')
@section('style')
    <style type="text/css">
    	select {
		    width: 100%;
		    height: 100%;
		}
    </style>
@endsection
@section('content')
	<div class="row">
		<h3 class="title1">Edit Product</h3>
		<div class="form-three widget-shadow">
            <form method="POST" action="{{ url('/admin/edit-product/'.$productDetail->id) }}" enctype="multipart/form-data">
                @csrf
                <div class="form-group row">
                    <label for="level" class="col-md-4 col-form-label text-md-right">{{ __('Under Category') }}</label>

                    <div class="col-md-6">
                        <select name="category_id" class="form-control">
                            <?php echo $categories_dropdown; ?>
                        </select>
                        @if ($errors->has('category_id'))
                            <span class="alert alert-danger">
                                <strong>{{ $errors->first('category_id') }}</strong>
                            </span>
                        @endif
                    </div>
                </div>
                <div class="form-group row">
                    <label for="product_name" class="col-md-4 col-form-label text-md-right">{{ __('Product Name') }}</label>

                    <div class="col-md-6">
                        <input id="product_name" type="text" class="form-control" name="product_name" value="{{ $productDetail['product_name'] }}">

                        @if ($errors->has('product_name'))
                            <span class="alert alert-danger">
                                <strong>{{ $errors->first('product_name') }}</strong>
                            </span>
                        @endif
                    </div>
                </div>
                <div class="form-group row">
                    <label for="product_code" class="col-md-4 col-form-label text-md-right">{{ __('Product Code') }}</label>

                    <div class="col-md-6">
                        <input id="product_code" type="text" class="form-control" name="product_code" value="{{ $productDetail['product_code'] }}">

                        @if ($errors->has('product_code'))
                            <span class="alert alert-danger">
                                <strong>{{ $errors->first('product_code') }}</strong>
                            </span>
                        @endif
                    </div>
                </div>
                <div class="form-group row">
                    <label for="product_color" class="col-md-4 col-form-label text-md-right">{{ __('Product Color') }}</label>

                    <div class="col-md-6">
                        <input id="product_color" type="text" class="form-control" name="product_color" value="{{ $productDetail['product_color'] }}">

                        @if ($errors->has('product_color'))
                            <span class="alert alert-danger">
                                <strong>{{ $errors->first('product_color') }}</strong>
                            </span>
                        @endif
                    </div>
                </div>

            	<div class="form-group row">
                    <label for="description" class="col-md-4 col-form-label text-md-right">{{ __('Description') }}</label>

                    <div class="col-md-6">
                        <input id="description" type="text" class="form-control" name="description" value="{{ $productDetail['description'] }}">

                        @if ($errors->has('description'))
                            <span class="alert alert-danger">
                                <strong>{{ $errors->first('description') }}</strong>
                            </span>
                        @endif
                    </div>
                </div>

            	<div class="form-group row">
                    <label for="price" class="col-md-4 col-form-label text-md-right">{{ __('PRICE') }}</label>

                    <div class="col-md-6">
                        <input id="price" type="text" class="form-control" name="price" value="{{ $productDetail['price'] }}">

                        @if ($errors->has('price'))
                            <span class="alert alert-danger">
                                <strong>{{ $errors->first('price') }}</strong>
                            </span>
                        @endif
                    </div>
                </div>
                <div class="form-group row">
                    <label for="image" class="col-md-4 col-form-label text-md-right">{{ __('IMAGE') }}</label>

                    <div class="col-md-6">
                        <input id="image" type="file" class="form-control" name="image" value="{{ old('image') }}">
                        <input type="hidden" name="current_image" value="{{$productDetail['image']}}">
                            <img src="{{asset('/backend/images/products/small/'.$productDetail['image'])}}" style="width: 100px;">| <a href="{{url('/admin/delete-product-image/'.$productDetail['id'])}}"> delete </a> 
                        @if ($errors->has('image'))
                            <span class="alert alert-danger">
                                <strong>{{ $errors->first('image') }}</strong>
                            </span>
                        @endif
                    </div>
                </div>

                <div class="form-group row mb-0" style="margin-top: 5%;">
                    <div class="col-md-6 offset-md-4">
                        <button type="submit" class="btn btn-primary">
                            Edit Product
                        </button>
                    </div>
                </div>
            </form>
		</div>
	</div>
@endsection