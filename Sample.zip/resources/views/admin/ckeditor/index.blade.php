@extends('admin.adminlayout.layout')

@section('content')
    <div class="main-page">
		<div class="panel panel-default">
            <div class="panel-body">
           		<table id="example" class="display" style="width:100%">
			        <thead>
			            <tr>
			                <th>ID</th>
			                <th>Content</th>
			                <th>Action</th>
			            </tr>
			        </thead>
			        <tbody>
			        	@foreach($ckeditor_detail as $single_detail)
			        		<tr>
			        			<td>{{$single_detail['id']}}</td>
			        			<td>{{$single_detail['content']}}</td>
			        			<td><a href="{{ URL::route('ckeditor.edit',$single_detail['id']) }}">
								<img border="0" alt="W3Schools" src="{{ url('/') .'/images/edit-button-blue-md.png' }}" width="50" height="25">
								</a></td>
			        		</tr>
			        	@endforeach
			        </tbody>
			    </table> 	
            </div>
        </div>
    </div>
@endsection
@section('javascript')
	<script type="text/javascript">
		$(document).ready(function(){
			$('#example').DataTable();
		});
	</script>
@endsection