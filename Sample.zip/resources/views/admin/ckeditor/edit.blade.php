@extends('admin.adminlayout.layout')

@section('content')
    <div class="main-page">
		<div class="row">
			<h3 class="title1">CK Editor Form</h3>
			<div class="form-three widget-shadow">
				<form action="{{ URL::route('ckeditor.update') }}" name="ckForm" method="post">
					@csrf
					<input type="hidden" name="id" value="{{$ckeditor_detail['id']}}">
					<textarea name="test_ckeditor" rows="1" cols="10">
						{{$ckeditor_detail['content']}} 
					</textarea><br>
					@if ($errors->has('test_ckeditor'))
                        <span class="alert alert-danger">
                            <strong>{{ $errors->first('test_ckeditor') }}</strong>
                        </span>
                    @endif
                    <br><br><br><br>
					<button type="submit" class="btn btn-primary">Submit</button>
            	</form>
			</div>
		</div>
    </div>
@endsection

@section('javascript')
	<script src="/vendor/unisharp/laravel-ckeditor/ckeditor.js"></script>
    <script src="/vendor/unisharp/laravel-ckeditor/adapters/jquery.js"></script>
    <script type="text/javascript">
        $('textarea').ckeditor();
        // $('.textarea').ckeditor(); // if class is prefered.
	</script>
@endsection