<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::get('admin/login','Admin\Auth\LoginController@showLoginForm')->name('admin.login.get');
Route::post('admin/login','Admin\Auth\LoginController@login')->name('admin.login.post');

Route::group(['middleware'=>'admin'],function(){
	Route::get('/user/detail','UserController@index')->name('user.index');

	Route::get('/user/create','UserController@create')->name('user.create');
	Route::post('/user/store','UserController@store')->name('user.store');

	Route::get('/user/edit/{id}','UserController@edit')->name('user.edit');
	Route::post('/user/update','UserController@update')->name('user.update');

	Route::get('/user/delete/{id}','UserController@delete')->name('user.delete');

	Route::get('/server-side/datatable','Admin\ServerSideDataTableController@index')->name('serverside.datatable.get');

	Route::get('downloadExcel/{type}', 'Admin\MaatwebsiteDemoController@downloadExcel')->name('download.excel');
	Route::post('importExcel', 'Admin\MaatwebsiteDemoController@importExcel');

	Route::get('/admin/country/state/city','Admin\CountryStateCityController@getCountryStateCity')->name('country.state.city');
	Route::post('/admin/country/state/city/store','Admin\CountryStateCityController@store')->name('country.state.city.post');
	Route::post('/admin/states','Admin\CountryStateCityController@getStates')->name('country.states');
	Route::post('/admin/cities','Admin\CountryStateCityController@getCities')->name('state.cities');

	/* Eloquent Tips & Technique */
	Route::get('/eloquent/tips','Admin\EloquentTipsController@getEloquentDetails')->name('eloquent.tips');
	
	/* Implementation of CK Editor */
	Route::get('/admin/ck-editor/index','CKEditorController@index')->name('ckeditor.index');
	Route::match(['get', 'post'], '/admin/ck-editor','CKEditorController@getCkeditor');
	
	Route::get('/admin/ck-editor/edit/{id}','CKEditorController@editCKEditor')->name('ckeditor.edit');
	Route::post('/admin/ck-editor/update','CKEditorController@updateCKEditor')->name('ckeditor.update');
	
	Route::get('/admin/dropzone', 'DropZoneContrller@dropzone');
	Route::post('/admin/dropzone/store', ['as'=>'dropzone.store','uses'=>'DropZoneContrller@dropzoneStore']);

	// File Upload with Progress bar
	Route::get('/admin/file-upload', 'FileController@fileUpload');
	Route::post('/admin/file-upload', 'FileController@fileUploadPost')->name('fileUploadPost');
	
	/* Start Routes for Ecommerce Website [ stack developers ] */
	
	// Categories Routes (Admin)
	Route::get('/admin/view-category','CategoryController@viewCategory')->name('category.view');
	Route::match(['get','post'],'/admin/add-category','CategoryController@addCategory');
	Route::match(['get','post'],'/admin/edit-category/{id}','CategoryController@editCategory');
	Route::match(['get','post'],'/admin/delete-category/{id}','CategoryController@deleteCategory');

	// Products Routes (Admin)
	Route::get('/admin/view-products','ProductsController@viewProducts')->name('products.view');
	Route::match(['get','post'],'/admin/add-product','ProductsController@addProduct');
	Route::match(['get','post'],'/admin/edit-product/{id}','ProductsController@editProduct');

	Route::get('/admin/delete-product/{id}','ProductsController@deleteProduct');
	Route::get('/admin/delete-product-image/{id}','ProductsController@deleteProductImage');

	Route::match(['get','post'], '/admin/add-attributes/{id}','ProductsController@addAttributes');

	/* End Routes for Ecommerce Website [ stack developers ] */

	Route::get('admin/logout','Admin\Auth\LoginController@logout')->name('admin.logout');
});

//admin password reset routes
Route::post('admin/password/email','Admin\Auth\ForgotPasswordController@sendResetLinkEmail')->name('admin.password.email');
Route::get('admin/password/reset','Admin\Auth\ForgotPasswordController@showLinkRequestForm')->name('admin.password.request');
Route::post('admin/password/reset','Admin\Auth\ResetPasswordController@reset');
Route::get('admin/password/reset/{token}','Admin\Auth\ResetPasswordController@showResetForm')->name('admin.password.reset');

/* Create for Making Admin Theme Integration */
Route::get('/test-theme','TestThemeController@testTheme')->name('test.theme');
// Route::get('/admin/home','Admin\HomeController@index')->name('admin.dashboard');