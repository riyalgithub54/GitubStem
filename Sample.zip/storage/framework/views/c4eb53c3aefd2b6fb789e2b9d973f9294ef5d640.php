<?php $__env->startSection('content'); ?>
    <div class="main-page">
		<div class="row">
			<h3 class="title1">CK Editor Form</h3>
			<div class="form-three widget-shadow">
				<form action="<?php echo e(url('/admin/ck-editor')); ?>" name="ckForm" method="post">
					<?php echo csrf_field(); ?>
					<textarea name="test_ckeditor" rows="1" cols="10"> 
					</textarea><br>
					<?php if($errors->has('test_ckeditor')): ?>
                        <span class="alert alert-danger">
                            <strong><?php echo e($errors->first('test_ckeditor')); ?></strong>
                        </span>
                    <?php endif; ?>
                    <br><br><br><br>
					<button type="submit" class="btn btn-primary">Submit</button>
            	</form>
			</div>
		</div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
	<script src="/vendor/unisharp/laravel-ckeditor/ckeditor.js"></script>
    <script src="/vendor/unisharp/laravel-ckeditor/adapters/jquery.js"></script>
    <script type="text/javascript">
        $('textarea').ckeditor();
        // $('.textarea').ckeditor(); // if class is prefered.
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.adminlayout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>