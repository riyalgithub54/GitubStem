<!-- new added graphs chart js-->
	
<script src="/backend/js/Chart.bundle.js"></script>
<script src="/backend/js/utils.js"></script>
	
<!-- Classie --><!-- for toggle left push menu script -->
	<script src="/backend/js/classie.js"></script>
	<script>
		var menuLeft = document.getElementById( 'cbp-spmenu-s1' ),
			showLeftPush = document.getElementById( 'showLeftPush' ),
			body = document.body;
			
		showLeftPush.onclick = function() {
			classie.toggle( this, 'active' );
			classie.toggle( body, 'cbp-spmenu-push-toright' );
			classie.toggle( menuLeft, 'cbp-spmenu-open' );
			disableOther( 'showLeftPush' );
		};
		

		function disableOther( button ) {
			if( button !== 'showLeftPush' ) {
				classie.toggle( showLeftPush, 'disabled' );
			}
		}
	</script>
<!-- //Classie --><!-- //for toggle left push menu script -->
	
<!--scrolling js-->
<script src="/backend/js/jquery.nicescroll.js"></script>
<script src="/backend/js/scripts.js"></script>
<!--//scrolling js-->

<!-- side nav js -->
<script src='/backend/js/SidebarNav.min.js' type='text/javascript'></script>
    <script>
      $('.sidebar-menu').SidebarNav()
    </script>
    <!-- //side nav js -->

</script>
<!-- //for index page weekly sales java script -->

<!-- Bootstrap Core JavaScript -->
<script src="/backend/js/bootstrap.js"> </script>
<!-- //Bootstrap Core JavaScript -->