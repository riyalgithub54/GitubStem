<?php $__env->startSection('content'); ?>
    <div class="main-page">
        <div class="panel panel-default">
            <div class="panel-heading" align="left">User Details | <a href="<?php echo e(URL::route('user.create')); ?>">Create User</a></div>
            <div class="panel-body">
                <table class="table table-striped">
                    <thead>
                      <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Contact No</th>
                        <th>Gender</th>
                        <th>Department</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $newuser_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single_user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><?php echo e($single_user['name']); ?></td>
                          <td><?php echo e($single_user['email']); ?></td>
                          <td><?php echo e($single_user['contact_no']); ?></td>
                          <td><?php echo e($single_user['gender']); ?></td>
                          <td><?php echo e($single_user['department']); ?></td>
                          <td>
                              <a href="<?php echo e(URL::route('user.edit',$single_user['id'])); ?>">Edit</a> | 
                              <a href="<?php echo e(URL::route('user.delete',$single_user['id'])); ?>">Delete</a></td>
                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php echo e($newuser_detail->links()); ?><br>
                <hr>
                <b>Additional Information :-</b><br> 
                <hr>
                <b>count:  </b><?php echo e($newuser_detail->count()); ?><br>
                <b>currentPage : </b><?php echo e($newuser_detail->currentPage()); ?><br>
                <b>firstItem : </b><?php echo e($newuser_detail->firstItem()); ?><br>
                <b>hasMorePages :  </b><?php echo e($newuser_detail->hasMorePages()); ?><br>
                <b>lastItem :  </b><?php echo e($newuser_detail->lastItem()); ?><br>
                <b>lastPage :  </b><?php echo e($newuser_detail->lastPage()); ?><br>
                <b>nextPageUrl : </b><?php echo e($newuser_detail->nextPageUrl()); ?><br>
                <b>perPage : </b><?php echo e($newuser_detail->perPage()); ?><br>
                <b>previousPageUrl : </b><?php echo e($newuser_detail->previousPageUrl()); ?><br>
                <b>total : </b><?php echo e($newuser_detail->total()); ?><br>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
  <script type="text/javascript">
    $(document).ready(function() {
      // show when page load
      // toastr.success('Page Loaded!');
        
        <?php if(Session::has('message')): ?>
          var type = "<?php echo e(Session::get('alert-type', 'info')); ?>";
          switch(type){
              
              case 'info':
                  toastr.info("<?php echo e(Session::get('message')); ?>");
                  break;
              
              case 'warning':
                  toastr.warning("<?php echo e(Session::get('message')); ?>");
                  break;

              case 'success':
                  toastr.success("<?php echo e(Session::get('message')); ?>");
                  break;

              case 'error':
                  toastr.error("<?php echo e(Session::get('message')); ?>");
                  break;
          }
        <?php endif; ?>
    });
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.adminlayout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>