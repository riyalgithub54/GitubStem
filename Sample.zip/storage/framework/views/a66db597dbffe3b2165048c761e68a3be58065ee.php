<?php $__env->startSection('content'); ?>
    <div class="main-page">
		<div class="panel panel-default">
            <div class="panel-body">
           		<table id="example" class="display" style="width:100%">
			        <thead>
			            <tr>
			                <th>Product ID</th>
			                <th>Category ID</th>
			                <th>Category Name</th>
			                <th>Product Name</th>
			                <th>Product Code</th>
			                <th>Product Color</th>
			                <th>Price</th>
			                <th>Image</th>
			                <th>Action</th>
			            </tr>
			        </thead>
			        <tbody>
			        	<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			        		<tr>
			        			<td><?php echo e($product['id']); ?></td>
			        			<td><?php echo e($product['category_id']); ?></td>
			        			<td><?php echo e($product['category_name']); ?></td>
			        			<td><?php echo e($product['product_name']); ?></td>
			        			<td><?php echo e($product['product_code']); ?></td>
			        			<td><?php echo e($product['product_color']); ?></td>
			        			<td><?php echo e($product['price']); ?></td>
			        			<td>
			        				<?php if(!empty($product['image'])): ?>
			        					<img src="<?php echo e(asset('/backend/images/products/small/'.$product['image'])); ?>" style="width: 60px;">
			        				<?php endif; ?>
			        			</td>
			        			<td><button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal<?php echo e($product['id']); ?>">View</button> | <a href="<?php echo e(url('/admin/edit-product/' . $product['id'] )); ?>" class="btn btn-warning btn-mini">Edit</a> | <a id="deleteConfirmation"  onclick="test(<?php echo $product['id']; ?>)" href="#" class="btn btn-danger btn-mini">Delete</a></td>
			        		</tr>
						    <!-- Modal -->
						  	<div class="modal fade" id="myModal<?php echo e($product['id']); ?>" role="dialog">
							    <div class="modal-dialog">
							    	<!-- Modal content-->
								    <div class="modal-content">
								        <div class="modal-header">
								          <button type="button" class="close" data-dismiss="modal">&times;</button>
								          <h4 class="modal-title"><?php echo e($product['product_name']); ?> Full Details</h4>
								        </div>
								        <div class="modal-body">
								          <p>Product ID			: 	<?php echo e($product['id']); ?></p>
								          <p>Category ID		: 	<?php echo e($product['category_id']); ?></p>
								          <p>Product Code		: 	<?php echo e($product['product_code']); ?></p>
								          <p>Product Color		: 	<?php echo e($product['product_color']); ?></p>
								          <p>Price				: 	<?php echo e($product['price']); ?></p>
								          <p>Description		: 	<?php echo e($product['description']); ?></p>
								        </div>
								        <div class="modal-footer">
								          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
								        </div>
								    </div>
							    </div>
						  	</div>
			        	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			        </tbody>
			    </table> 	
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
	<script type="text/javascript">
		$(document).ready(function(){
			$('#example').DataTable();
		});

		// $('#deleteConfirmation').click(function(){
		// 	if(confirm('Are you sure you want to delete this Product')){
		// 		return true;
		// 	}
		// 	return false;
		// });
		
		function test(test){
			var url = "<?php echo e(url('/admin/delete-product/')); ?>" + "/"+test;
			$.confirm({
			    title: 'Alert!',
			    content: 'Simple alert!',
			    theme: 'modern',
			    buttons: {
			        confirm: function () {
			            window.location.href = url;
			        },
			        cancel: function () {
			            // $.alert('Canceled!');
			        }
			    }
			});
		}

		// $('#deleteConfirmation').click(function(){
			
		// });
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.adminlayout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>