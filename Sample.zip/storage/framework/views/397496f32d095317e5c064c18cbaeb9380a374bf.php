<?php $__env->startSection('style'); ?>
    <style type="text/css">
    	select {
		    width: 100%;
		    height: 100%;
		}
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="row">
		<h3 class="title1">Edit Category</h3>
		<div class="form-three widget-shadow">
            <form method="POST" action="<?php echo e(url('/admin/edit-category/'.$category_detail['id'])); ?>">
                <?php echo csrf_field(); ?>

                <div class="form-group row">
                    <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Name')); ?></label>

                    <div class="col-md-6">
                        <input id="name" type="text" class="form-control" name="name" value="<?php echo e($category_detail['name']); ?>">

                        <?php if($errors->has('name')): ?>
                            <span class="alert alert-danger">
                                <strong><?php echo e($errors->first('name')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group row">
                    <label for="parent_id" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Category Level')); ?></label>

                    <div class="col-md-6">
                        <select name="parent_id">
                            <option value="0">Main Category</option>
                            <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($single->id); ?>" <?php if($single->id == $category_detail['parent_id']): ?> selected <?php endif; ?>><?php echo e($single->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                        <?php if($errors->has('parent_id')): ?>
                            <span class="alert alert-danger">
                                <strong><?php echo e($errors->first('parent_id')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

            	<div class="form-group row">
                    <label for="description" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Description')); ?></label>

                    <div class="col-md-6">
                        <input id="description" type="text" class="form-control" name="description" value="<?php echo e($category_detail['description']); ?>">

                        <?php if($errors->has('description')): ?>
                            <span class="alert alert-danger">
                                <strong><?php echo e($errors->first('description')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

            	<div class="form-group row">
                    <label for="url" class="col-md-4 col-form-label text-md-right"><?php echo e(__('URL')); ?></label>

                    <div class="col-md-6">
                        <input id="url" type="text" class="form-control" name="url" value="<?php echo e($category_detail['url']); ?>">

                        <?php if($errors->has('url')): ?>
                            <span class="alert alert-danger">
                                <strong><?php echo e($errors->first('url')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group row mb-0" style="margin-top: 5%;">
                    <div class="col-md-6 offset-md-4">
                        <button type="submit" class="btn btn-primary">
                            Edit Category
                        </button>
                    </div>
                </div>
            </form>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.adminlayout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>