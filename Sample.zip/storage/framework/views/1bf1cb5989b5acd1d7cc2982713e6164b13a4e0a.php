<?php $__env->startSection('content'); ?>

<a href="<?php echo e(URL::to('downloadExcel/xls')); ?>"><button class="btn btn-success">Download Excel xls</button></a>
<a href="<?php echo e(URL::to('downloadExcel/xlsx')); ?>"><button class="btn btn-success">Download Excel xlsx</button></a>
<a href="<?php echo e(URL::to('downloadExcel/csv')); ?>"><button class="btn btn-success">Download CSV</button></a>
<form style="border: 4px solid #a1a1a1;margin-top: 15px;padding: 10px;" action="<?php echo e(URL::to('importExcel')); ?>" class="form-horizontal" method="post" enctype="multipart/form-data">
	<?php echo csrf_field(); ?>
	<input type="file" name="import_file" />
	<button class="btn btn-primary">Import File</button>
</form>
    <div class="main-page">
		<div class="panel panel-default">
            <div class="panel-body">
           		<table id="example" class="display" style="width:100%">
			        <thead>
			            <tr>
			                <th>Name</th>
			                <th>Email</th>
			                <th>Contact-No</th>
			                <th>Gender</th>
			                <th>Department</th>
			            </tr>
			        </thead>
			        <tbody>
			        	<?php $__currentLoopData = $newuser_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singleuser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			        		<tr>
			        			<td><?php echo e($singleuser['name']); ?></td>
			        			<td><?php echo e($singleuser['email']); ?></td>
			        			<td><?php echo e($singleuser['gender']); ?></td>
			        			<td><?php echo e($singleuser['contact_no']); ?></td>
			        			<td><?php echo e($singleuser['department']); ?></td>
			        		</tr>
			        	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			        </tbody>
			    </table> 	
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
	<script type="text/javascript">
		$(document).ready(function(){
			$('#example').DataTable();
		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.adminlayout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>