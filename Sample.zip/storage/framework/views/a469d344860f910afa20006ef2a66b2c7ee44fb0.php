<?php $__env->startSection('content'); ?>
    <div class="main-page">
		<div class="panel panel-default">
            <div class="panel-body">
           		<table id="example" class="display" style="width:100%">
			        <thead>
			            <tr>
			                <th>ID</th>
			                <th>Cateogry Name</th>
			                <th>Category Level</th>
			                <th>URL</th>
			                <th>Action</th>
			            </tr>
			        </thead>
			        <tbody>
			        	<?php $__currentLoopData = $category_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			        		<tr>
			        			<td><?php echo e($single_category['id']); ?></td>
			        			<td><?php echo e($single_category['name']); ?></td>
			        			<td><?php echo e($single_category['parent_id']); ?></td>
			        			<td><?php echo e($single_category['url']); ?></td>
			        			<td><a href="<?php echo e(url('/admin/edit-category/' . $single_category['id'] )); ?>"><img border="0" alt="<?php echo e($single_category['name']); ?>" src="<?php echo e(url('/') .'/images/edit-button-blue-md.png'); ?>" width="50" height="25"></a> || <a id="deleteConfirmation" href="<?php echo e(url('/admin/delete-category/' . $single_category['id'] )); ?>"><img border="0" alt="<?php echo e($single_category['name']); ?>" src="<?php echo e(url('/') .'/images/delete-png.png'); ?>" width="50" height="25"></a></td>
			        		</tr>
			        	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			        </tbody>
			    </table> 	
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
	<script type="text/javascript">
		$(document).ready(function(){
			$('#example').DataTable();
		});

		$('#deleteConfirmation').click(function(){
			if(confirm('Are you sure you want to delete this Category')){
				return true;
			}
			return false;
		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.adminlayout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>