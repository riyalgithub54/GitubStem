<?php $__env->startSection('content'); ?>
<meta name="_token" content="<?php echo e(csrf_token()); ?>" />
    <div class="main-page">
		<div class="row">
			<h3 class="title1">Ajax :- Country State City</h3>
			<div class="form-three widget-shadow">
				<form id="myForm" name="myForm" method="post"  enctype="multipart/form-data">
					<?php echo csrf_field(); ?>
                	<div class="form-group row">
	                    <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Enter Name')); ?></label>
	                    <div class="col-md-6">
	                    	<input id="name" type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>">
	                    	<span class="alert alert-danger">
                                <strong id="error_name"></strong>
                            </span>
	                    </div>
	                </div>
                	<div class="form-group row">
	                    <label for="address" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Enter Address')); ?></label>
	                    <div class="col-md-6">
	                    	<input id="address" type="text" class="form-control" name="address" value="<?php echo e(old('address')); ?>">
	                    	<span class="alert alert-danger">
                                <strong id="error_address"></strong>
                            </span>
	                    </div>
	                </div>
                	<div class="form-group row">
	                    <label for="country" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Select Country')); ?></label>
	                    <div class="col-md-6">
	                    	<select name="country" id="country_id" class="form-control1">
	                    		<option value="" style="display: none;">Select Country</option>
	                    		<?php $__currentLoopData = $country_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single_country_key => $single_country_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                    			<option value="<?php echo e($single_country_key); ?>"><?php echo e($single_country_value); ?></option>
	                    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	                    	</select>
                            <span class="alert alert-danger">
                                <strong id="error_country"></strong>
                            </span>
	                    </div>
	                </div>
                	<div class="form-group row">
	                    <label for="state" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Select State')); ?></label>
	                    <div class="col-md-6">
	                    	<select name="state" id="state_id" class="form-control1">
	                    		<option value="" style="display: none;">Select State</option>
	                    	</select>
                            <span class="alert alert-danger">
                                <strong id="error_state"></strong>
                            </span>
	                    </div>
	                </div>
                	<div class="form-group row">
	                    <label for="city" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Select City')); ?></label>
	                    <div class="col-md-6">
	                    	<select name="city" id="city_id" class="form-control1">
	                    		<option value="" style="display: none;">Select City</option>
	                    	</select>
                            <span class="alert alert-danger">
                                <strong id="error_city"></strong>
                            </span>
	                    </div>
	                </div>
	                <div class="form-group row mb-0" style="margin-top: 5%;">
	                    <div class="col-md-6 offset-md-6">
	                        <button type="button" class="btn btn-primary" id="submitForm">
	                            Add Emp Address
	                        </button>
	                    </div>
	                </div>
            	</form>
			</div>
		</div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
	<script type="text/javascript">
		$(document).ready(function(){
			$('#submitForm').click(function(e){

				var name = $('#name').val();
				if(name != ""){
					$('#error_name').text("");
				}
				var address = $('#address').val();
				if(address != ""){
					$('#error_address').text("");
				}
				// console.log("test:-" +profile_picture);
               // 	e.preventDefault();
               // 	$.ajaxSetup({
               //    	headers: {
               //        'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
               //    	}
              	// });

				var submitURL = "<?php echo e(URL::route('country.state.city.post')); ?>";
				var name = $('#name').val();
				var address = $('#address').val();
				var selectedCountry = $("#country_id option:selected").val();
				var selectedState = $("#state_id option:selected").val();
				var selectedCity = $("#city_id option:selected").val();
				var token = "<?php echo e(csrf_token()); ?>";
			  	
			  	$.ajax({
				    type: 'POST',
				    url: submitURL,
				    data: { _token:token,name:name, address:address, country: selectedCountry,state: selectedState,city: selectedCity},
				    dataType: 'json',
				    success:function(res){
		           		console.log(res.message);
		           		alert(res.message);
		           		window.location.assign("<?php echo e(URL::route('country.state.city')); ?>")
		           	},
				    error:function(response){
				    	// console.log(response);
		       //     		console.log(response.responseJSON['errors']['city']);
		           		$('#error_name').text(response.responseJSON['errors']['name']);
		           		$('#error_address').text(response.responseJSON['errors']['address']);
		           		$('#error_country').text(response.responseJSON['errors']['country']);
		           		$('#error_state').text(response.responseJSON['errors']['state']);
		           		$('#error_city').text(response.responseJSON['errors']['city']);
		           	}
				});
			});

			$('#country_id').change(function(){
				$('#state_id').empty();
				$('#city_id').empty();
				var getStateUrl = "<?php echo e(URL::route('country.states')); ?>";
				var country_name = $('option:selected', this).text();
				var country_id = $("#country_id option:selected").val();
				var token = "<?php echo e(csrf_token()); ?>";
				if(country_id != null){
					$('#error_country').text("");
				}

				$.ajax({
				    type: 'POST',
				    url: getStateUrl,
				    data: { _token:token, country_id: country_id},
				    dataType: 'json',
				    success:function(res){
				    	console.table(res.states);
	           			$('#state_id').append('<option value="" style="display: none;">Select State</option>');
	           			$('#city_id').append('<option value="" style="display: none;">Select city</option>');
		           		$.each( res.states, function( key, value ) {
		           			// console.log( key + ": " + value );
		           			$('#state_id').append('<option value="'+key+'">'+value+'</option>')
						});
		           	},
				    error:function(response){
				    	console.log(response);
		           	}
				});

			});

			$('#state_id').change(function(){
				$('#city_id').empty();
				var getCityUrl = "<?php echo e(URL::route('state.cities')); ?>";
				var state_name = $('option:selected', this).text();
				var state_id = $("#state_id option:selected").val();
				var token = "<?php echo e(csrf_token()); ?>";
				if(state_id != null){
					$('#error_state').text("");
				}

				$.ajax({
				    type: 'POST',
				    url: getCityUrl,
				    data: { _token:token, state_id: state_id},
				    dataType: 'json',
				    success:function(res){
	           			$('#city_id').append('<option value="" style="display: none;">Select city</option>');
		           		$.each( res.cities, function( key, value ) {
		           			// console.log( key + ": " + value );
		           			$('#city_id').append('<option value="'+key+'">'+value+'</option>')
						});
		           	},
				    error:function(response){
				    	console.log(response);
		           	}
				});
			});

			$('#city_id').change(function(){
				var city_name = $('option:selected', this).text();
				var city_id = $("#city_id option:selected").val();
				if(city_id != null){
					$('#error_city').text("");
				}
			});
		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.adminlayout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>