<?php $__env->startSection('content'); ?>
    <div class="main-page">
		<div class="panel panel-default">
            <div class="panel-body">
           		<table id="example" class="display" style="width:100%">
			        <thead>
			            <tr>
			                <th>ID</th>
			                <th>Content</th>
			                <th>Action</th>
			            </tr>
			        </thead>
			        <tbody>
			        	<?php $__currentLoopData = $ckeditor_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			        		<tr>
			        			<td><?php echo e($single_detail['id']); ?></td>
			        			<td><?php echo e($single_detail['content']); ?></td>
			        			<td><a href="<?php echo e(URL::route('ckeditor.edit',$single_detail['id'])); ?>">
								<img border="0" alt="W3Schools" src="<?php echo e(url('/') .'/images/edit-button-blue-md.png'); ?>" width="50" height="25">
								</a></td>
			        		</tr>
			        	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			        </tbody>
			    </table> 	
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
	<script type="text/javascript">
		$(document).ready(function(){
			$('#example').DataTable();
		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.adminlayout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>