<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="row">
		<h3 class="title1">Generate Dynamic Form</h3>
		<div class="form-three widget-shadow">
            <form name="add_name" id="add_name">
                <?php echo csrf_field(); ?>
                <div class="alert alert-danger print-error-msg" style="display:none">
                    <ul></ul>
                </div>
                <div class="alert alert-success print-success-msg" style="display:none">
                    <ul></ul>
                </div>
                <div class="table-responsive">
                    <table class="table table-bordered" id="dynamic_field">  
                        <tr>  
                            <td><input type="text" name="name[]" placeholder="Enter your Name" class="form-control name_list" /></td>  
                            <td><button type="button" name="add" id="add" class="btn btn-success">Add More</button></td>  
                        </tr>
                    </table> 
                    <input type="button" name="submit" id="submit" class="btn btn-info" value="Submit" />  
                </div>
            </form>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
    <script type="text/javascript">
        $(document).ready(function(){
            var postURL = "<?php echo e(URL::route('emp.dynamic.post')); ?>";
            var i = 1;
            $('#add').click(function(){  
                 i++;  
                 $('#dynamic_field').append('<tr id="row'+i+'" class="dynamic-added"><td><input type="text" name="name[]" placeholder="Enter your Name" class="form-control name_list" /></td><td><button type="button" name="remove" id="'+i+'" class="btn btn-danger btn_remove">X</button></td></tr>');  
            });
            $(document).on('click', '.btn_remove', function(){  
                var button_id = $(this).attr("id");   
                $('#row'+button_id+'').remove();  
            });
            $('#submit').click(function(){        
                $.ajax({
                    url:postURL,  
                    method:"POST",  
                    data:$('#add_name').serialize(),
                    type:'json',
                    success:function(data)  
                    {
                        if(data.error){
                            printErrorMsg(data.error);
                        }else{
                                i=1;
                                $('.dynamic-added').remove();
                                $('#add_name')[0].reset();
                                $(".print-success-msg").find("ul").html('');
                                $(".print-success-msg").css('display','block');
                                $(".print-error-msg").css('display','none');
                                $(".print-success-msg").find("ul").append('<li>Record Inserted Successfully.</li>');
                        }
                    }  
                });  
            });
            function printErrorMsg (msg) {
               $(".print-error-msg").find("ul").html('');
               $(".print-error-msg").css('display','block');
               $(".print-success-msg").css('display','none');
               $.each( msg, function( key, value ) {
                  $(".print-error-msg").find("ul").append('<li>'+value+'</li>');
               });
            }
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('employee.layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>