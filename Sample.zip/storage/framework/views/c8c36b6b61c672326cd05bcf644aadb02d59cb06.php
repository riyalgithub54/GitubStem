<?php $__env->startSection('style'); ?>
    <style type="text/css">
    	select {
		    width: 100%;
		    height: 100%;
		}
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="row">
		<h3 class="title1">Add Product</h3>
		<div class="form-three widget-shadow">
            <form method="POST" action="<?php echo e(url('/admin/add-product')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group row">
                    <label for="level" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Under Category')); ?></label>

                    <div class="col-md-6">
                        <select name="category_id" class="form-control">
                            <?php echo $categories_dropdown; ?>
                        </select>
                        <?php if($errors->has('category_id')): ?>
                            <span class="alert alert-danger">
                                <strong><?php echo e($errors->first('category_id')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="product_name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Product Name')); ?></label>

                    <div class="col-md-6">
                        <input id="product_name" type="text" class="form-control" name="product_name" value="<?php echo e(old('product_name')); ?>">

                        <?php if($errors->has('product_name')): ?>
                            <span class="alert alert-danger">
                                <strong><?php echo e($errors->first('product_name')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="product_code" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Product Code')); ?></label>

                    <div class="col-md-6">
                        <input id="product_code" type="text" class="form-control" name="product_code" value="<?php echo e(old('product_code')); ?>">

                        <?php if($errors->has('product_code')): ?>
                            <span class="alert alert-danger">
                                <strong><?php echo e($errors->first('product_code')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="product_color" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Product Color')); ?></label>

                    <div class="col-md-6">
                        <input id="product_color" type="text" class="form-control" name="product_color" value="<?php echo e(old('product_color')); ?>">

                        <?php if($errors->has('product_color')): ?>
                            <span class="alert alert-danger">
                                <strong><?php echo e($errors->first('product_color')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

            	<div class="form-group row">
                    <label for="description" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Description')); ?></label>

                    <div class="col-md-6">
                        <input id="description" type="text" class="form-control" name="description" value="<?php echo e(old('description')); ?>">

                        <?php if($errors->has('description')): ?>
                            <span class="alert alert-danger">
                                <strong><?php echo e($errors->first('description')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

            	<div class="form-group row">
                    <label for="price" class="col-md-4 col-form-label text-md-right"><?php echo e(__('PRICE')); ?></label>

                    <div class="col-md-6">
                        <input id="price" type="text" class="form-control" name="price" value="<?php echo e(old('price')); ?>">

                        <?php if($errors->has('price')): ?>
                            <span class="alert alert-danger">
                                <strong><?php echo e($errors->first('price')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="image" class="col-md-4 col-form-label text-md-right"><?php echo e(__('IMAGE')); ?></label>

                    <div class="col-md-6">
                        <input id="image" type="file" class="form-control" name="image" value="<?php echo e(old('image')); ?>">

                        <?php if($errors->has('image')): ?>
                            <span class="alert alert-danger">
                                <strong><?php echo e($errors->first('image')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group row mb-0" style="margin-top: 5%;">
                    <div class="col-md-6 offset-md-4">
                        <button type="submit" class="btn btn-primary">
                            Create Product
                        </button>
                    </div>
                </div>
            </form>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.adminlayout.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>